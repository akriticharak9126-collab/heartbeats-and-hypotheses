HEARTBEATS & HYPOTHESES — WEBSITE STARTER
=========================================

WHAT'S INCLUDED
- index.html: homepage
- journal.html: article archive
- about.html: writer/about page
- articles/: three standalone starter articles
- assets/style.css: full responsive visual design
- assets/script.js: mobile navigation

HOW TO PREVIEW
1. Extract this ZIP.
2. Open index.html in a browser.
3. Keep the folder structure intact; the pages link to each other using relative paths.

HOW TO EDIT
- Replace or expand the article text in articles/.
- Update the author bio in about.html.
- Change colours near the top of assets/style.css under :root.
- Change the contact email in the HTML files before publishing. The current address is a placeholder.
- Add future articles by copying an existing article HTML file and adding a card to journal.html.

IMPORTANT EDITORIAL NOTE
The three included articles are starter drafts for the site's structure and voice. They contain general educational explanations, but they are not fully referenced research articles. Before publishing them as researched science essays, verify claims and add accurate citations to textbooks, review papers and/or primary research. Do not present the starter copy as a substitute for reading sources.

PUBLISHING
This is a static website. It can be hosted on Netlify, Cloudflare Pages or GitHub Pages. It is not online yet. A custom domain is optional and may cost money. No backend, account system, comments, search index or newsletter signup is included.

CONTACT
Replace hello@heartbeatsandhypotheses.com with an email address you actually want public before deployment.
